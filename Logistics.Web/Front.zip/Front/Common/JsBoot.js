﻿document.write('<script type="text/javascript" src="/Public/JS/jquery.min.js"></script>');
document.write('<script type="text/javascript" src="/Public/JS/JQPublic.js"></script>');
document.write('<script type="text/javascript" src="/Public/JS/Public.js"></script>');
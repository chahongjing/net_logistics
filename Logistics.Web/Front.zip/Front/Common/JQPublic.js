﻿// 文件清单
// ajaxSetup
// fillForm
// getFormData
// handlerAjax
// setValue
// setText
// setAttr
// processAjax


// 函数名称： fillForm
// 函数功能： 将实体填充到表单中
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-02-14 23:10:38
function fillForm(formId, data) {
    var item, itemName, itemType;
    var arrType, arrCheckboxValue;

    arrType = ["text", "hidden", "password"];
    for (itemName in data) {
        if (data[itemName] == null) { continue; }
        item = $("#" + formId + " #" + itemName);
        if (item.length == 0) { item = $("#" + formId + " [name=" + itemName + "]"); }
        itemType = item.attr("type");

        // 文本, 隐藏, 密码, 多行文本, 下拉
        if ((item.is("input") && isInArray(arrType, itemType)) || item.is("textarea") || item.is("select")) {
            item.val((data[itemName] == null || data[itemName] == undefined) ? "" : data[itemName]);
            // 复选
        } else if (item.is("input") && item.attr("type") == "checkbox") {
            arrCheckboxValue = data[itemName].split(",");
            item.each(function() {
                if (isInArray(arrCheckboxValue, $(this).val())) { $(this).prop("checked", "checked"); }
                else { $(this).removeAttr("checked"); }
            });
            // 单选
        } else if (item.is("input") && item.attr("type") == "radio") {
            item.each(function() {
                if (data[itemName] == $(this).val()) { $(this).prop("checked", "checked"); }
                else { $(this).removeAttr("checked"); }
            });
            // 其它
        } else {
            item.text((data[itemName] == null || data[itemName] == undefined) ? "" : data[itemName]);
        }
    }
}
// 函数名称： fillForm
// 函数功能： 将实体填充到表单中
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-02-14 23:10:38
function fillFormOther(formId, data, prefix) {
    var item, itemName, itemType;
    var arrType, arrCheckboxValue;

    if (!prefix) {
        prefix = "";
    } else {
        prefix += "_";
    }

    arrType = ["text", "hidden", "password"];
    for (itemName in data) {
        if (data[itemName] == null) { continue; }
        item = $("#" + formId + " #" + prefix + itemName);
        if (item.length == 0) { item = $("#" + formId + " [name=" + prefix + itemName + "]"); }
        itemType = item.attr("type");

        // 文本, 隐藏, 密码, 多行文本, 下拉
        if ((item.is("input") && isInArray(arrType, itemType)) || item.is("textarea") || item.is("select")) {
            item.val((data[itemName] == null || data[itemName] == undefined) ? "" : data[itemName]);
            // 复选
        } else if (item.is("input") && item.attr("type") == "checkbox") {
            arrCheckboxValue = data[itemName].split(",");
            item.each(function() {
                if (isInArray(arrCheckboxValue, $(this).val())) { $(this).prop("checked", "checked"); }
                else { $(this).removeAttr("checked"); }
            });
            // 单选
        } else if (item.is("input") && item.attr("type") == "radio") {
            item.each(function() {
                if (data[itemName] == $(this).val()) { $(this).prop("checked", "checked"); }
                else { $(this).removeAttr("checked"); }
            });
            // 其它
        } else {
            item.text((data[itemName] == null || data[itemName] == undefined) ? "" : data[itemName]);
        }
    }
}
// 函数名称： getFormData
// 函数功能： 获取表单数据
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-02-15 22:08:39
function getFormData(formId) {
    var data = {};
    var items = $("#" + formId + " [IsSave=true]");
    var itemType, itemId, itemName, checkBoxValue;
    var item;
    var arrType;

    arrType = ["text", "hidden", "password"];

    $("#" + formId + " [IsSave=true]").each(function() {
        item = $(this);
        itemType = item.attr("type");
        itemId = item.attr("id");
        itemName = item.attr("name");
        if (!itemId) { itemId = itemName; }

        // 文本, 隐藏, 密码, 多行文本, 下拉
        if ((item.is("input") && isInArray(arrType, itemType)) || item.is("textarea") || item.is("select")) {
            data[itemId] = item.val();
            // 复选
        } else if (item.is("input") && item.attr("type") == "checkbox") {
            checkBoxValue = "";
            $('input:checkbox[name="' + itemName + '"]:checked').each(function() {
                checkBoxValue += (checkBoxValue == "" ? "" : ",") + $(this).val();
            });
            data[itemId] = checkBoxValue;
            // 单选
        } else if (item.is("input") && item.attr("type") == "radio") {
            data[itemId] = $('input:radio[name="' + itemName + '"]:checked').val();
            // 其它
        } else {
            data[itemId] = item.text();
        }
    });
    return data;
}
// 函数名称： processAjax
// 函数功能： JQuery Ajax操作
// 函数参数： optionData.url: ajax请求地址; optionData.getData: 用户数据(Json); optionData.postData: 用户数据(Json)
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-02-22 21:01:54
function processAjax(optionData) {
    var strReturn, url;
    var startIndex, endIndex;
    var jReturn;

    if (!optionData.url) {
        return { "Status": "ERROR", "Message": "optionData.url参数未设置!", Value: null }
    }
    if (optionData.getData && typeof (optionData.getData) != "object") {
        return { "Status": "ERROR", "Message": "optionData.getData类型不匹配或参数未设置!", Value: null }
    }
    if (optionData.postData && typeof (optionData.postData) != "object") {
        return { "Status": "ERROR", "Message": "optionData.postData类型不匹配或参数未设置!", Value: null }
    }

    if (!optionData.getData) {
        url = optionData.url;
    } else {
        url = optionData.url + (optionData.url.indexOf("?") > -1 ? "&" : "?") + $.param(optionData.getData);
    }

    $.ajax({
        url: url,
        type: "post",
        async: optionData.async || true,
        dataType: "text",
        data: optionData.postData,
        success: function(data) { strReturn = data; }
    });
    try {
        jReturn = eval("(" + strReturn + ")");
    } catch (ex) {
        startIndex = strReturn.indexOf("<title>");
        if (startIndex > 0) {
            endIndex = strReturn.indexOf("</title>");
            jReturn = { Status: "ERROR", Message: strReturn.substring(startIndex + 7, endIndex), Value: null };
        } else if (!strReturn) {
            jReturn = { Status: "ERROR", Message: "请求返回数据为空！", Value: null };
        } else {
            jReturn = { Status: "ERROR", Message: "返回Json数据失败！", Value: null };
        }
    }
    return jReturn;
}
// 函数名称： setValue
// 函数功能： 设置值
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-03-05 22:36:20
function setValue(id, val, pre, aft) {
    if (pre === null || pre === undefined) pre = "";
    if (aft === null || aft === undefined) aft = "";
    if (val === null || val === undefined) {
        $("#" + id).val(pre + aft);
    } else {
        $("#" + id).val(pre + val + aft);
    }
}
// 函数名称： setText
// 函数功能： 设置文本
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-03-05 22:36:29
function setText(id, val, pre, aft) {
    if (pre === null || pre === undefined) pre = "";
    if (aft === null || aft === undefined) aft = "";
    if (val === null || val === undefined) {
        $("#" + id).text(pre + aft);
    } else {
        $("#" + id).text(pre + val + aft);
    }
}
// 函数名称： setAttr
// 函数功能： 设置属性
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-03-05 22:36:39
function setAttr(id, attr, val, pre, aft) {
    if (pre === null || pre === undefined) pre = "";
    if (aft === null || aft === undefined) aft = "";
    if (val === null || val === undefined) {
        $("#" + id).attr(attr, pre + aft);
    } else {
        $("#" + id).attr(attr, pre + val + aft);
    }
}
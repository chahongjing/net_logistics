﻿window.ToolSite = window.ToolSite || {};
window.ToolSite.Controls = window.ToolSite.Controls || {};

(function(ns) {
    ns.registerNameSpace = function(nameSpace) {
        var arrNameSpace;
        var ns;

        if (!nameSpace) {
            return window;
        }
        arrNameSpace = nameSpace.split(".");
        ns = window;
        for (var i = 0; i < arrNameSpace.length; i++) {
            if (i == 0 && arrNameSpace[i] == "window") {
                continue;
            }

            ns[arrNameSpace[i]] = ns[arrNameSpace[i]] || {};
            ns = ns[arrNameSpace[i]];
        }
        return ns;
    }
})(window.ToolSite);

window.Utility = window.Utility || {};
(function(ns) {
    // 函数名称： processAjax
    // 函数功能： JQuery Ajax操作
    // 函数参数： optionData.url: ajax请求地址; optionData.getData: 用户数据(Json); optionData.postData: 用户数据(Json)
    // 返 回 值： 无
    // 创 建 人： zengjy01
    // 创建日期： 2014-02-22 21:01:54
    ns.processAjax = function(optionData) {
        var strReturn, url;
        var startIndex, endIndex;
        var jReturn;

        if (!optionData.url) {
            return { "Status": "ERROR", "Message": "optionData.url参数未设置!", Value: null }
        }
        if (optionData.getData && typeof (optionData.getData) != "object") {
            return { "Status": "ERROR", "Message": "optionData.getData类型不匹配或参数未设置!", Value: null }
        }
        if (optionData.postData && typeof (optionData.postData) != "object") {
            return { "Status": "ERROR", "Message": "optionData.postData类型不匹配或参数未设置!", Value: null }
        }

        if (!optionData.getData) {
            url = optionData.url;
        } else {
            url = optionData.url + (optionData.url.indexOf("?") > -1 ? "&" : "?") + $.param(optionData.getData);
        }

        $.ajax({
            url: url,
            type: "post",
            async: optionData.async || true,
            dataType: "text",
            data: optionData.postData,
            success: function(data) { strReturn = data; }
        });
        try {
            jReturn = eval("(" + strReturn + ")");
        } catch (ex) {
            startIndex = strReturn.indexOf("<title>");
            if (startIndex > 0) {
                endIndex = strReturn.indexOf("</title>");
                jReturn = { Status: "ERROR", Message: strReturn.substring(startIndex + 7, endIndex), Value: null };
            } else if (!strReturn) {
                jReturn = { Status: "ERROR", Message: "请求返回数据为空！", Value: null };
            } else {
                jReturn = { Status: "ERROR", Message: "返回Json数据失败！", Value: null };
            }
        }
        return jReturn;
    }
})(window.Utility);

// 函数名称： ajaxSetup
// 函数功能： JQuery Ajax全局错误处理函数
// 函数参数： 无
// 返 回 值： 无
// 创 建 人： zengjy01
// 创建日期： 2014-02-22 21:01:54
$.ajaxSetup({ error: function(data) {
    var j = jQuery.parseJSON(data.responseText);
    alert(j.Message);
}
});